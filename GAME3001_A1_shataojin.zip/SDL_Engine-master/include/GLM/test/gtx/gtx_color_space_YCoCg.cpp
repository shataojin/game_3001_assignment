#include <glm/gtx/color_space_YCoCg.hpp>

int main()
{
	int Error(0);

	return Error;
}
